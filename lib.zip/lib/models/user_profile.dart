import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';

@immutable
class UserProfile {
  final String uid;
  final String displayName;
  final String email;
  final String? photoUrl;
  final String? countryCode;
  final String? languageCode;
  final String themePreference;
  final String performanceMode;
  final String? manualPerformanceLevel;
  final bool notificationsEnabled;
  // --- ENCRYPTION FIELDS ---
  final bool isEncryptionEnabled;
  final String? wrappedDEK; // Data Encryption Key, encrypted with KEK
  final String? salt;       // Salt for deriving KEK from master password

  // --- PREMIUM FIELDS ---
  final bool isPremium;
  final DateTime? premiumUntil;
  final DateTime? trialStartedAt;


  const UserProfile({
    required this.uid,
    required this.displayName,
    required this.email,
    this.photoUrl,
    this.countryCode,
    this.languageCode,
    this.themePreference = 'system',
    this.performanceMode = 'auto',
    this.manualPerformanceLevel,
    this.notificationsEnabled = true,
    this.isEncryptionEnabled = false,
    this.wrappedDEK,
    this.salt,
    this.isPremium = false,
    this.premiumUntil,
    this.trialStartedAt,
  });

  UserProfile copyWith({
    String? displayName,
    String? photoUrl,
    String? countryCode,
    String? languageCode,
    String? themePreference,
    String? performanceMode,
    String? manualPerformanceLevel,
    bool? notificationsEnabled,
    bool? isEncryptionEnabled,
    String? wrappedDEK,
    String? salt,
    bool? isPremium,
    DateTime? premiumUntil,
    DateTime? trialStartedAt,
  }) {
    return UserProfile(
      uid: uid,
      email: email,
      displayName: displayName ?? this.displayName,
      photoUrl: photoUrl ?? this.photoUrl,
      countryCode: countryCode ?? this.countryCode,
      languageCode: languageCode ?? this.languageCode,
      themePreference: themePreference ?? this.themePreference,
      performanceMode: performanceMode ?? this.performanceMode,
      manualPerformanceLevel:
          manualPerformanceLevel ?? this.manualPerformanceLevel,
      notificationsEnabled: notificationsEnabled ?? this.notificationsEnabled,
      isEncryptionEnabled: isEncryptionEnabled ?? this.isEncryptionEnabled,
      wrappedDEK: wrappedDEK ?? this.wrappedDEK,
      salt: salt ?? this.salt,
      isPremium: isPremium ?? this.isPremium,
      premiumUntil: premiumUntil ?? this.premiumUntil,
      trialStartedAt: trialStartedAt ?? this.trialStartedAt,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'displayName': displayName,
      'email': email,
      'photoUrl': photoUrl,
      'countryCode': countryCode,
      'languageCode': languageCode,
      'themePreference': themePreference,
      'performanceMode': performanceMode,
      'manualPerformanceLevel': manualPerformanceLevel,
      'notificationsEnabled': notificationsEnabled,
      'isEncryptionEnabled': isEncryptionEnabled,
      'wrappedDEK': wrappedDEK,
      'salt': salt,
      'isPremium': isPremium,
      'premiumUntil': premiumUntil != null ? Timestamp.fromDate(premiumUntil!) : null,
      'trialStartedAt': trialStartedAt != null ? Timestamp.fromDate(trialStartedAt!) : null,
    };
  }

  factory UserProfile.fromJson(String uid, Map<String, dynamic> json) {
    return UserProfile(
      uid: uid,
      displayName: json['displayName'] as String,
      email: json['email'] as String,
      photoUrl: json['photoUrl'] as String?,
      countryCode: json['countryCode'] as String?,
      languageCode: json['languageCode'] as String?,
      themePreference: json['themePreference'] as String? ?? 'system',
      performanceMode: json['performanceMode'] as String? ?? 'auto',
      manualPerformanceLevel: json['manualPerformanceLevel'] as String?,
      notificationsEnabled: json['notificationsEnabled'] as bool? ?? true,
      isEncryptionEnabled: json['isEncryptionEnabled'] as bool? ?? false,
      wrappedDEK: json['wrappedDEK'] as String?,
      salt: json['salt'] as String?,
      isPremium: json['isPremium'] as bool? ?? false,
      premiumUntil: (json['premiumUntil'] as Timestamp?)?.toDate(),
      trialStartedAt: (json['trialStartedAt'] as Timestamp?)?.toDate(),
    );
  }
}

