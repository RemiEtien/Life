import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:audioplayers/audioplayers.dart';
import 'dart:async';
import 'package:lifeline/l10n/app_localizations.dart';
import 'package:lifeline/providers/application_providers.dart';
import 'package:lifeline/screens/auth_gate.dart';
import 'package:lifeline/screens/legal/consent_screen.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SplashScreen extends ConsumerStatefulWidget {
  const SplashScreen({super.key});

  @override
  ConsumerState<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends ConsumerState<SplashScreen> {
  late AudioPlayer _audioPlayer;
  String _statusMessage = "";

  @override
  void initState() {
    super.initState();
    _audioPlayer = AudioPlayer();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      // ИСПРАВЛЕНИЕ: Явно устанавливаем начальную локаль в нашем провайдере.
      // Если локаль не была загружена из SharedPreferences (первый запуск),
      // мы инициализируем ее текущей локалью из контекста виджета.
      // Это гарантирует, что при создании нового профиля будет использоваться правильный язык.
      if (ref.read(localeProvider) == null) {
          final currentLocale = Localizations.localeOf(context);
          ref.read(localeProvider.notifier).setLocale(currentLocale);
      }
      
      // The locale is already initialized in main.dart
      // Now we just set the initial message and start the sequence.
      if (mounted) {
        final l10n = AppLocalizations.of(context);
        // ИСПРАВЛЕНИЕ: Добавлена проверка на null для l10n
        if (l10n != null) {
          setState(() {
            _statusMessage = l10n.splashMessageInitializing;
          });
          _startSequence(l10n);
        }
      }
    });
  }

  Future<void> _startSequence(AppLocalizations l10n) async {
    // Воспроизводим звук, но не ждем его окончания
    try {
      _audioPlayer.play(AssetSource('sounds/intro_phrase.mp3'));
    } catch (e) {
      // Игнорируем ошибку, если звук не проигрался
      if (kDebugMode) {
        print("Could not play intro sound: $e");
      }
    }

    // Минимальное время показа заставки
    await Future.delayed(const Duration(seconds: 3));
    if (!mounted) return;

    // --- ШАГ 1: Проверка согласия ---
    if (mounted) {
      setState(() => _statusMessage = l10n.splashMessageCheckingSettings);
    }
    final prefs = await SharedPreferences.getInstance();
    // Принудительно перезагружаем данные с диска на всякий случай
    await prefs.reload();
    final bool hasConsented = prefs.getBool('hasConsented') ?? false;

    if (kDebugMode) {
      print("[SplashScreen] Has user consented? -> $hasConsented");
    }

    if (!hasConsented) {
      if (mounted) {
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (_) => const ConsentScreen()),
        );
      }
      return; // Останавливаем выполнение, если согласия нет
    }

    // --- ШАГ 2: Проверка аутентификации ---
    if (mounted) {
      setState(() => _statusMessage = l10n.splashMessageAuthenticating);
    }

    // Ждем первого ответа от потока состояния аутентификации
    final user = await ref.read(authServiceProvider).authStateChanges.first;
    if (!mounted) return;

    if (user == null) {
      // Пользователя нет -> переходим к AuthGate (который покажет LoginScreen)
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => const AuthGate()),
      );
      return; // Останавливаем выполнение
    }

    // --- НОВОЕ: Синхронизируем локаль с профилем пользователя после авторизации ---
    await ref.read(localeProvider.notifier).syncLocaleWithUserProfile();
    if (!mounted) return;

    // --- ШАГ 3: Начальная синхронизация ---
    if (mounted) setState(() => _statusMessage = l10n.splashMessageSyncing);
    try {
      // Выполняем "тихую" синхронизацию при запуске
      await ref
          .read(syncServiceProvider)
          .syncFromCloudToLocal(isInitialSync: true);
    } catch (e) {
      if (kDebugMode) {
        print(
            "[SplashScreen] Initial sync failed, proceeding with local data. Error: $e");
      }
      // Ошибка не критична, приложение продолжит работать с локальными данными
    }

    if (!mounted) return;

    // --- ШАГ 4: Переход к основному приложению ---
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (_) => const AuthGate()),
    );
  }

  @override
  void dispose() {
    _audioPlayer.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset(
              'assets/logo.png',
              width: 300,
              height: 300,
            ),
            const SizedBox(height: 40),
            const CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
            ),
            const SizedBox(height: 20),
            AnimatedSwitcher(
              duration: const Duration(milliseconds: 300),
              child: Text(
                _statusMessage,
                key: ValueKey(_statusMessage),
                style: TextStyle(color: Colors.white.withOpacity(0.7)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

